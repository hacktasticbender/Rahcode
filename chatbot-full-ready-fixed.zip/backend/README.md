# Backend Notes

## Tables
- `chats`: each row belongs to one user (`user_id`).
- `messages`: linked to chats; `role` is `user` or `assistant`.

## Permissions (role: user)
- chats:
  - select/insert/update/delete with row check: `{"user_id":{"_eq":"X-Hasura-User-Id"}}`
  - insert column preset: `user_id` from session variable.
  - update columns: `title`, `updated_at`.
- messages:
  - select row check: `{"chat":{"user_id":{"_eq":"X-Hasura-User-Id"}}}`
  - insert row check: same as above
  - allowed insert columns: `chat_id`, `role`, `content`

## Action
- Add an Action named `sendMessage` with SDL from `hasura/actions.graphql`.
- Handler URL: n8n Production Webhook URL.
- Enable "Forward client headers".
- Permissions: allow role `user`.
