import React, { useMemo, useState, useEffect } from 'react'
import { NhostClient } from '@nhost/nhost-js'
import { ApolloClient, InMemoryCache, ApolloProvider, split, HttpLink } from '@apollo/client'
import { GraphQLWsLink } from '@apollo/client/link/subscriptions'
import { getMainDefinition } from '@apollo/client/utilities'
import { createClient as createWSClient } from 'graphql-ws'
import { useQuery, useMutation, useSubscription } from '@apollo/client'

import { Q_CHATS, M_NEW_CHAT, S_MESSAGES, M_SEND_USER, A_SEND_BOT } from './graphql/documents.js'

const NHOST_BACKEND_URL = import.meta.env.VITE_NHOST_BACKEND_URL
const HASURA_HTTP = import.meta.env.VITE_HASURA_GRAPHQL_HTTP
const HASURA_WS = import.meta.env.VITE_HASURA_GRAPHQL_WS
const nhost = new NhostClient({ backendUrl: NHOST_BACKEND_URL })

function useApollo() {
  const httpLink = new HttpLink({
    uri: HASURA_HTTP,
    fetch: async (uri, options = {}) => {
      const token = (await nhost.auth.getSession())?.accessToken ?? null
      options.headers = { ...(options.headers || {}), Authorization: token ? `Bearer ${token}` : '' }
      return fetch(uri, options)
    }
  })

  const wsLink = new GraphQLWsLink(createWSClient({
    url: HASURA_WS,
    connectionParams: async () => {
      const token = (await nhost.auth.getSession())?.accessToken ?? null
      return { headers: { Authorization: token ? `Bearer ${token}` : '' } }
    }
  }))

  const link = split(
    ({ query }) => {
      const def = getMainDefinition(query)
      return def.kind === 'OperationDefinition' && def.operation === 'subscription'
    },
    wsLink,
    httpLink
  )

  return new ApolloClient({ link, cache: new InMemoryCache() })
}

function AuthBox({ onAuth }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [mode, setMode] = useState('sign-in')

  const go = async (e) => {
    e.preventDefault()
    if (mode === 'sign-in') {
      const { error } = await nhost.auth.signIn({ email, password })
      if (error) return alert(error.message)
    } else {
      const { error } = await nhost.auth.signUp({ email, password })
      if (error) return alert(error.message)
    }
    onAuth(await nhost.auth.isAuthenticatedAsync())
  }

  return (
    <form onSubmit={go} style={{ maxWidth: 360, margin: '64px auto', display: 'grid', gap: 8 }}>
      <h2>Nhost Email {mode === 'sign-in' ? 'Sign In' : 'Sign Up'}</h2>
      <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button type="submit">{mode === 'sign-in' ? 'Sign In' : 'Create Account'}</button>
      <button type="button" onClick={()=>setMode(mode==='sign-in'?'sign-up':'sign-in')}>
        Switch to {mode==='sign-in'?'Sign Up':'Sign In'}
      </button>
    </form>
  )
}

function ChatList({ onPick }) {
  const { data, loading, refetch } = useQuery(Q_CHATS)
  const [title, setTitle] = useState('')
  const [createChat, { loading: creating }] = useMutation(M_NEW_CHAT, {
    onCompleted: () => { setTitle(''); refetch() }
  })

  return (
    <div style={{ width: 320, borderRight: '1px solid #ddd', padding: 12 }}>
      <h3>Chats</h3>
      <div style={{ display:'flex', gap:8 }}>
        <input placeholder="New chat title" value={title} onChange={e=>setTitle(e.target.value)} />
        <button disabled={!title||creating} onClick={()=>createChat({ variables:{ title }})}>+</button>
      </div>
      {loading ? <p>Loading…</p> : (
        <ul style={{ listStyle:'none', padding:0 }}>
          {data?.chats?.map(c => (
            <li key={c.id}>
              <button onClick={()=>onPick(c)} style={{ width:'100%', textAlign:'left' }}>{c.title}</button>
            </li>
          ))}
        </ul>
      )}
      <button onClick={() => { nhost.auth.signOut(); location.reload() }} style={{ marginTop: 12 }}>Sign out</button>
    </div>
  )
}

function Messages({ chat }) {
  const { data } = useSubscription(S_MESSAGES, { variables: { chat_id: chat.id }})
  const [text, setText] = useState('')
  const [sendUser] = useMutation(M_SEND_USER)
  const [sendBot, { loading: botLoading }] = useMutation(A_SEND_BOT)

  const send = async () => {
    const content = text.trim(); if (!content) return
    setText('')
    await sendUser({ variables: { chat_id: chat.id, content }})
    await sendBot({ variables: { chat_id: chat.id, content }})
  }

  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', height:'100%' }}>
      <div style={{ flex:1, overflow:'auto', padding: 12 }}>
        {(data?.messages ?? []).map(m => (
          <div key={m.id} style={{ margin: '6px 0', display:'flex', justifyContent: m.role==='user'?'flex-end':'flex-start' }}>
            <div style={{ padding:8, borderRadius:8, background: m.role==='user' ? '#e1f0ff' : '#f5f5f5', maxWidth:'70%' }}>
              <small style={{ opacity:0.6 }}>{m.role}</small>
              <div>{m.content}</div>
            </div>
          </div>
        ))}
        {botLoading && <div><em>assistant is typing…</em></div>}
      </div>
      <div style={{ display:'flex', gap:8, borderTop:'1px solid #ddd', padding:12 }}>
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="Type a message…" onKeyDown={e=>e.key==='Enter'&&send()} />
        <button onClick={send}>Send</button>
      </div>
    </div>
  )
}

function Shell() {
  const [authed, setAuthed] = useState(false)
  const client = useMemo(() => useApollo(), [authed])

  useEffect(() => {
    const sub = nhost.auth.onAuthStateChanged(() => setAuthed(nhost.auth.isAuthenticated()))
    setAuthed(nhost.auth.isAuthenticated())
    return () => sub.unsubscribe?.()
  }, [])

  if (!authed) return <AuthBox onAuth={setAuthed} />

  const [current, setCurrent] = useState(null)
  return (
    <ApolloProvider client={client}>
      <div style={{ display:'flex', height:'100vh' }}>
        <ChatList onPick={setCurrent} />
        {current ? <Messages chat={current}/> : <div style={{ padding:24 }}>Pick or create a chat</div>}
      </div>
    </ApolloProvider>
  )
}

export default function App(){ return <Shell/> }
