import { gql } from '@apollo/client'

export const Q_CHATS = gql`
  query MyChats {
    chats(order_by: { updated_at: desc }) {
      id
      title
      created_at
      updated_at
    }
  }
`

export const M_NEW_CHAT = gql`
  mutation NewChat($title:String!) {
    insert_chats_one(object:{title:$title}) { id title }
  }
`

export const S_MESSAGES = gql`
  subscription MessagesSub($chat_id: uuid!) {
    messages(where:{chat_id:{_eq:$chat_id}}, order_by:{created_at:asc}) {
      id role content created_at
    }
  }
`

export const M_SEND_USER = gql`
  mutation SendUserMsg($chat_id: uuid!, $content: String!) {
    insert_messages_one(object:{chat_id:$chat_id, role:"user", content:$content}) { id }
  }
`

export const A_SEND_BOT = gql`
  mutation SendBot($chat_id: uuid!, $content: String!) {
    sendMessage(chat_id:$chat_id, content:$content) { reply }
  }
`
